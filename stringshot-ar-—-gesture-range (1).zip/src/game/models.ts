import * as THREE from 'three';
import { CEILING_Y, FLOOR_Y, GUARDIAN_BOX_HALF_SIZE } from './types';

export interface ARGunRig {
  root: THREE.Group;
  gunPivot: THREE.Group;
  slide: THREE.Mesh;
  magazine: THREE.Mesh;
  muzzleFlash: THREE.Group;
  muzzlePoint: THREE.Object3D;
  laserBeam: THREE.Mesh;
}

export interface HangingTargetRig {
  root: THREE.Group;
  boardGroup: THREE.Group;
  hitDisc: THREE.Mesh;
  stringMesh: THREE.Mesh;
  trolleyMesh: THREE.Mesh;
  decalGroup: THREE.Group;
  faceMaterial: THREE.MeshStandardMaterial;
}

export interface GuardianBoxRig {
  root: THREE.Group;
  borderMaterial: THREE.MeshBasicMaterial;
  gridMaterial: THREE.MeshBasicMaterial;
  pillarMaterial: THREE.MeshBasicMaterial;
}

export interface AimReticleRig {
  root: THREE.Group;
  outerRing: THREE.Mesh;
  innerDot: THREE.Mesh;
  ticksGroup: THREE.Group;
  outerMaterial: THREE.MeshBasicMaterial;
  innerMaterial: THREE.MeshBasicMaterial;
}

export const TARGET_BOARD_WIDTH = 0.78;
export const TARGET_BOARD_HEIGHT = 1.18;
export const TARGET_CHEST_OFFSET_Y = -0.105; // Local Y of the X-ring center on the board

export function createTargetFaceTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const w = 512;
  const h = 768;
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;

  const cx = w / 2;

  // Off-white shooting range cardstock background
  ctx.fillStyle = '#F5F3EE';
  ctx.fillRect(0, 0, w, h);

  // Subtle paper/cardboard grain
  for (let i = 0; i < 2400; i++) {
    const x = Math.random() * w;
    const y = Math.random() * h;
    ctx.fillStyle = i % 2 === 0 ? 'rgba(0,0,0,0.022)' : 'rgba(255,255,255,0.03)';
    ctx.fillRect(x, y, 2, 2);
  }

  // Thin outer range sheet border
  ctx.strokeStyle = 'rgba(15, 23, 42, 0.16)';
  ctx.lineWidth = 4;
  ctx.strokeRect(8, 8, w - 16, h - 16);

  // Draw bold black human silhouette (head, ears/jaw, neck, shoulders, torso)
  ctx.fillStyle = '#090B0E';
  ctx.beginPath();

  // Bottom left of torso
  ctx.moveTo(cx - 148, h - 42);
  // Left waist/arm taper up to shoulder
  ctx.bezierCurveTo(cx - 156, 520, cx - 178, 410, cx - 170, 295);
  // Left shoulder curve to neck
  ctx.bezierCurveTo(cx - 166, 250, cx - 122, 236, cx - 68, 224);
  // Left neck up to jaw
  ctx.bezierCurveTo(cx - 52, 214, cx - 48, 198, cx - 50, 180);
  // Left jaw & subtle ear notch
  ctx.bezierCurveTo(cx - 58, 168, cx - 64, 152, cx - 62, 134);
  ctx.lineTo(cx - 72, 126);
  ctx.lineTo(cx - 64, 114);
  // Left skull up to crown
  ctx.bezierCurveTo(cx - 76, 62, cx - 48, 28, cx, 28);
  // Right skull down to ear
  ctx.bezierCurveTo(cx + 48, 28, cx + 76, 62, cx + 64, 114);
  ctx.lineTo(cx + 72, 126);
  ctx.lineTo(cx + 62, 134);
  // Right jaw & neck
  ctx.bezierCurveTo(cx + 64, 152, cx + 58, 168, cx + 50, 180);
  ctx.bezierCurveTo(cx + 48, 198, cx + 52, 214, cx + 68, 224);
  // Right shoulder curve
  ctx.bezierCurveTo(cx + 122, 236, cx + 166, 250, cx + 170, 295);
  // Right arm/torso down to bottom right
  ctx.bezierCurveTo(cx + 178, 410, cx + 156, 520, cx + 148, h - 42);
  ctx.closePath();
  ctx.fill();

  // Helper to draw concentric stadium/pill-shaped scoring rings inside torso
  const drawStadiumRing = (halfW: number, halfH: number, centerY: number, lineWidth: number) => {
    const r = halfW;
    const straight = Math.max(0, halfH - r);
    ctx.beginPath();
    ctx.moveTo(cx - r, centerY - straight);
    ctx.arc(cx, centerY - straight, r, Math.PI, 0, false);
    ctx.lineTo(cx + r, centerY + straight);
    ctx.arc(cx, centerY + straight, r, 0, Math.PI, false);
    ctx.closePath();
    ctx.lineWidth = lineWidth;
    ctx.strokeStyle = '#F8FAFC';
    ctx.stroke();
  };

  // Chest center corresponds to local Y = -0.105m -> canvas Y = (0.5 - (-0.105 / 1.18)) * 768 ~= 452
  const chestY = 452;

  // Rings matching B-27 reference: 7, 8, 9, inner 10-halo, and X bullseye
  const ringSpecs = [
    { halfW: 138, halfH: 214, lw: 2.8 }, // Ring 7
    { halfW: 106, halfH: 164, lw: 2.6 }, // Ring 8
    { halfW: 74, halfH: 118, lw: 2.6 },  // Ring 9
    { halfW: 44, halfH: 72, lw: 2.2 },   // Outer X halo
    { halfW: 26, halfH: 44, lw: 2.6 },   // Inner X ring
  ];

  for (const spec of ringSpecs) {
    drawStadiumRing(spec.halfW, spec.halfH, chestY, spec.lw);
  }

  // White ring numbers (7, 8, 9 on top, bottom, left, right + bold X in center)
  ctx.fillStyle = '#F8FAFC';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '700 20px "Plus Jakarta Sans", sans-serif';

  const labels: Array<{ text: string; rx: number; ry: number }> = [
    { text: '7', rx: 0, ry: -194 },
    { text: '7', rx: 0, ry: 194 },
    { text: '7', rx: -122, ry: 0 },
    { text: '7', rx: 122, ry: 0 },
    { text: '8', rx: 0, ry: -146 },
    { text: '8', rx: 0, ry: 146 },
    { text: '8', rx: -90, ry: 0 },
    { text: '8', rx: 90, ry: 0 },
    { text: '9', rx: 0, ry: -98 },
    { text: '9', rx: 0, ry: 98 },
    { text: '9', rx: -59, ry: 0 },
    { text: '9', rx: 59, ry: 0 },
  ];

  for (const lbl of labels) {
    ctx.fillText(lbl.text, cx + lbl.rx, chestY + lbl.ry);
  }

  // Bold center X
  ctx.font = '700 32px "Plus Jakarta Sans", sans-serif';
  ctx.fillText('X', cx, chestY + 1);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createGuardianFloorTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, size, size);

  // Translucent safety floor fill
  ctx.fillStyle = 'rgba(34, 211, 238, 0.08)';
  ctx.fillRect(0, 0, size, size);

  // Diagonal hazard stripes near outer edge
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.lineWidth = 3;
  const step = 64;
  for (let i = 0; i <= size; i += step) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, size);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(size, i);
    ctx.stroke();
  }

  // Center foot stance marker
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, 54, 0, Math.PI * 2);
  ctx.stroke();

  // Outer crisp border
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 18;
  ctx.strokeRect(9, 9, size - 18, size - 18);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

export function createARGunModel(): ARGunRig {
  const root = new THREE.Group();
  const gunPivot = new THREE.Group();
  root.add(gunPivot);

  const polymerMat = new THREE.MeshStandardMaterial({
    color: 0x1a1f26,
    roughness: 0.78,
    metalness: 0.15,
  });

  const gripMat = new THREE.MeshStandardMaterial({
    color: 0x12161b,
    roughness: 0.92,
    metalness: 0.05,
  });

  const slideMat = new THREE.MeshPhysicalMaterial({
    color: 0x4b5563,
    roughness: 0.24,
    metalness: 0.88,
    clearcoat: 0.35,
    clearcoatRoughness: 0.25,
  });

  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.18,
    metalness: 0.94,
  });

  const accentCyanMat = new THREE.MeshStandardMaterial({
    color: 0x06b6d4,
    emissive: 0x0891b2,
    emissiveIntensity: 1.4,
    roughness: 0.2,
    metalness: 0.3,
  });

  const tritiumMat = new THREE.MeshBasicMaterial({ color: 0x4ade80 });
  const amberDotMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });

  // 1. Lower polymer frame (-Z is forward barrel direction)
  const frameGeo = new THREE.BoxGeometry(0.036, 0.032, 0.22);
  const frame = new THREE.Mesh(frameGeo, polymerMat);
  frame.position.set(0, -0.005, -0.05);
  gunPivot.add(frame);

  // 2. Ergonomic angled pistol grip
  const gripGeo = new THREE.BoxGeometry(0.032, 0.125, 0.048);
  const grip = new THREE.Mesh(gripGeo, gripMat);
  grip.position.set(0, -0.072, 0.025);
  grip.rotation.x = 0.24;
  gunPivot.add(grip);

  // 3. Magazine baseplate (animated on reload)
  const magGeo = new THREE.BoxGeometry(0.03, 0.024, 0.052);
  const magazine = new THREE.Mesh(magGeo, steelMat);
  magazine.position.set(0, -0.135, 0.04);
  magazine.rotation.x = 0.24;
  gunPivot.add(magazine);

  // 4. Trigger guard & trigger
  const guardBottom = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.007, 0.052), polymerMat);
  guardBottom.position.set(0, -0.042, -0.02);
  gunPivot.add(guardBottom);

  const guardFront = new THREE.Mesh(new THREE.BoxGeometry(0.016, 0.028, 0.008), polymerMat);
  guardFront.position.set(0, -0.028, -0.044);
  gunPivot.add(guardFront);

  const trigger = new THREE.Mesh(new THREE.BoxGeometry(0.008, 0.022, 0.009), steelMat);
  trigger.position.set(0, -0.026, -0.014);
  trigger.rotation.x = -0.3;
  gunPivot.add(trigger);

  // 5. Reciprocating metal slide
  const slideGeo = new THREE.BoxGeometry(0.038, 0.036, 0.23);
  const slide = new THREE.Mesh(slideGeo, slideMat);
  slide.position.set(0, 0.028, -0.052);
  gunPivot.add(slide);

  // Slide serrations / ribs
  for (let i = 0; i < 5; i++) {
    const rib = new THREE.Mesh(new THREE.BoxGeometry(0.041, 0.024, 0.004), polymerMat);
    rib.position.set(0, 0, 0.065 + i * 0.009);
    slide.add(rib);
  }

  // 6. Fluted inner barrel & muzzle brake
  const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.011, 0.25, 16), steelMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.024, -0.062);
  gunPivot.add(barrel);

  const muzzleBrake = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.03, 0.036), polymerMat);
  muzzleBrake.position.set(0, 0.022, -0.185);
  gunPivot.add(muzzleBrake);

  // 7. Holographic reflex optic on top of slide
  const opticHousing = new THREE.Mesh(new THREE.BoxGeometry(0.034, 0.022, 0.046), polymerMat);
  opticHousing.position.set(0, 0.03, 0.02);
  slide.add(opticHousing);

  const opticLens = new THREE.Mesh(
    new THREE.PlaneGeometry(0.026, 0.018),
    new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.32,
      roughness: 0.05,
      metalness: 0.1,
      side: THREE.DoubleSide,
    }),
  );
  opticLens.position.set(0, 0.032, 0.004);
  slide.add(opticLens);

  const opticDot = new THREE.Mesh(new THREE.SphereGeometry(0.0022, 8, 8), amberDotMat);
  opticDot.position.set(0, 0.032, 0.018);
  slide.add(opticDot);

  // Tritium front & rear sights
  const frontSight = new THREE.Mesh(new THREE.BoxGeometry(0.006, 0.012, 0.008), polymerMat);
  frontSight.position.set(0, 0.024, -0.105);
  slide.add(frontSight);

  const frontPip = new THREE.Mesh(new THREE.SphereGeometry(0.0022, 8, 8), tritiumMat);
  frontPip.position.set(0, 0.027, -0.101);
  slide.add(frontPip);

  // 8. Under-barrel laser sight module + subtle guide ray
  const laserModule = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.022, 0.065), polymerMat);
  laserModule.position.set(0, -0.026, -0.12);
  gunPivot.add(laserModule);

  const laserEmitter = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.006, 12), accentCyanMat);
  laserEmitter.rotation.x = Math.PI / 2;
  laserEmitter.position.set(0, -0.026, -0.155);
  gunPivot.add(laserEmitter);

  const laserGeo = new THREE.CylinderGeometry(0.0014, 0.0014, 1, 6);
  laserGeo.translate(0, 0.5, 0);
  laserGeo.rotateX(-Math.PI / 2);
  const laserMat = new THREE.MeshBasicMaterial({
    color: 0x22d3ee,
    transparent: true,
    opacity: 0.32,
    depthWrite: false,
  });
  const laserBeam = new THREE.Mesh(laserGeo, laserMat);
  laserBeam.position.set(0, -0.026, -0.16);
  gunPivot.add(laserBeam);

  // 9. Muzzle point & dynamic flash
  const muzzlePoint = new THREE.Object3D();
  muzzlePoint.position.set(0, 0.024, -0.205);
  gunPivot.add(muzzlePoint);

  const muzzleFlash = new THREE.Group();
  muzzleFlash.position.copy(muzzlePoint.position);
  muzzleFlash.visible = false;
  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xfbbf24,
    transparent: true,
    opacity: 0.9,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  for (let i = 0; i < 3; i++) {
    const plane = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 0.06), flashMat);
    plane.rotation.z = (i * Math.PI) / 3;
    muzzleFlash.add(plane);
  }
  const coreFlash = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 10), flashMat);
  muzzleFlash.add(coreFlash);
  gunPivot.add(muzzleFlash);

  return {
    root,
    gunPivot,
    slide,
    magazine,
    muzzleFlash,
    muzzlePoint,
    laserBeam,
  };
}

export function createHangingTargetModel(
  faceTexture: THREE.Texture,
  boardWidth = TARGET_BOARD_WIDTH,
  boardHeight = TARGET_BOARD_HEIGHT,
): HangingTargetRig {
  const root = new THREE.Group();
  const boardGroup = new THREE.Group();
  root.add(boardGroup);

  const halfH = boardHeight * 0.5;

  // 1. Overhead ceiling trolley puck
  const trolleyMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.4,
    metalness: 0.75,
  });
  const trolleyMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 0.08, 16), trolleyMat);
  trolleyMesh.position.set(0, CEILING_Y, 0);
  root.add(trolleyMesh);

  // 2. Taut vertical suspension string (unit height = 1, scaled dynamically)
  const stringGeo = new THREE.CylinderGeometry(0.009, 0.009, 1, 8);
  const stringMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.65,
    metalness: 0.1,
  });
  const stringMesh = new THREE.Mesh(stringGeo, stringMat);
  root.add(stringMesh);

  // 3. Heavy kraft/cardboard target backing slab
  const backingMat = new THREE.MeshStandardMaterial({
    color: 0x8b7355,
    roughness: 0.88,
    metalness: 0.04,
  });
  const backingMesh = new THREE.Mesh(
    new THREE.BoxGeometry(boardWidth + 0.03, boardHeight + 0.03, 0.036),
    backingMat,
  );
  boardGroup.add(backingMesh);

  // 4. Steel top hanger clamp bar & eyelet
  const rimMat = new THREE.MeshStandardMaterial({
    color: 0x94a3b8,
    roughness: 0.32,
    metalness: 0.85,
  });
  const clampBar = new THREE.Mesh(
    new THREE.BoxGeometry(boardWidth + 0.05, 0.055, 0.054),
    rimMat,
  );
  clampBar.position.set(0, halfH + 0.025, 0);
  boardGroup.add(clampBar);

  const bracketMesh = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.06, 0.06), rimMat);
  bracketMesh.position.set(0, halfH + 0.06, 0);
  boardGroup.add(bracketMesh);

  const eyelet = new THREE.Mesh(new THREE.TorusGeometry(0.038, 0.01, 8, 16), rimMat);
  eyelet.position.set(0, halfH + 0.11, 0);
  boardGroup.add(eyelet);

  // 5. Front B-27 silhouette face
  const faceMaterial = new THREE.MeshStandardMaterial({
    map: faceTexture,
    roughness: 0.68,
    metalness: 0.03,
  });
  const hitDisc = new THREE.Mesh(new THREE.PlaneGeometry(boardWidth, boardHeight), faceMaterial);
  hitDisc.position.z = 0.02;
  boardGroup.add(hitDisc);

  // 6. Decal group for 3D bullet holes stuck onto the board
  const decalGroup = new THREE.Group();
  decalGroup.position.z = 0.024;
  boardGroup.add(decalGroup);

  return {
    root,
    boardGroup,
    hitDisc,
    stringMesh,
    trolleyMesh,
    decalGroup,
    faceMaterial,
  };
}

export function createGuardianBox(maxAnisotropy: number): GuardianBoxRig {
  const root = new THREE.Group();
  root.position.set(0, FLOOR_Y, 0);
  root.visible = false; // Strictly hidden until camera pitches down toward feet!

  const half = GUARDIAN_BOX_HALF_SIZE;
  const full = half * 2;

  const gridTex = createGuardianFloorTexture(maxAnisotropy);
  const gridMaterial = new THREE.MeshBasicMaterial({
    map: gridTex,
    color: 0x22d3ee,
    transparent: true,
    opacity: 0.85,
    side: THREE.DoubleSide,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    polygonOffsetUnits: -1,
  });

  const floorPlane = new THREE.Mesh(new THREE.PlaneGeometry(full, full), gridMaterial);
  floorPlane.rotation.x = -Math.PI / 2;
  root.add(floorPlane);

  // Glowing perimeter bars
  const borderMaterial = new THREE.MeshBasicMaterial({
    color: 0x22d3ee,
    transparent: true,
    opacity: 0.95,
  });

  const barThickness = 0.035;
  const barHeight = 0.02;
  const edges: Array<[number, number, number, number]> = [
    [0, -half, full, barThickness],
    [0, half, full, barThickness],
    [-half, 0, barThickness, full],
    [half, 0, barThickness, full],
  ];
  for (const [x, z, w, d] of edges) {
    const bar = new THREE.Mesh(new THREE.BoxGeometry(w, barHeight, d), borderMaterial);
    bar.position.set(x, barHeight * 0.5 + 0.005, z);
    root.add(bar);
  }

  // Vertical corner boundary beacons so the square box reads clearly in 3D space
  const pillarMaterial = new THREE.MeshBasicMaterial({
    color: 0x22d3ee,
    transparent: true,
    opacity: 0.65,
  });
  const corners: Array<[number, number]> = [
    [-half, -half],
    [half, -half],
    [-half, half],
    [half, half],
  ];
  for (const [cx, cz] of corners) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.02, 0.42, 8), pillarMaterial);
    post.position.set(cx, 0.21, cz);
    root.add(post);
  }

  return {
    root,
    borderMaterial,
    gridMaterial,
    pillarMaterial,
  };
}

export function createAimReticle(): AimReticleRig {
  const root = new THREE.Group();
  root.visible = false;

  const outerMaterial = new THREE.MeshBasicMaterial({
    color: 0x22d3ee,
    transparent: true,
    opacity: 0.92,
    side: THREE.DoubleSide,
    depthWrite: false,
    depthTest: false,
  });

  const innerMaterial = new THREE.MeshBasicMaterial({
    color: 0xf59e0b,
    transparent: true,
    opacity: 0.98,
    side: THREE.DoubleSide,
    depthWrite: false,
    depthTest: false,
  });

  const outerRing = new THREE.Mesh(new THREE.RingGeometry(0.86, 1.0, 40), outerMaterial);
  outerRing.renderOrder = 50;
  root.add(outerRing);

  const innerDot = new THREE.Mesh(new THREE.CircleGeometry(0.018, 20), innerMaterial);
  innerDot.renderOrder = 51;
  root.add(innerDot);

  const ticksGroup = new THREE.Group();
  for (let i = 0; i < 4; i++) {
    const tick = new THREE.Mesh(new THREE.PlaneGeometry(0.016, 0.07), outerMaterial);
    const angle = (i * Math.PI) / 2;
    tick.position.set(Math.cos(angle) * 0.14, Math.sin(angle) * 0.14, 0);
    tick.rotation.z = angle + Math.PI / 2;
    tick.renderOrder = 50;
    ticksGroup.add(tick);
  }
  root.add(ticksGroup);

  return {
    root,
    outerRing,
    innerDot,
    ticksGroup,
    outerMaterial,
    innerMaterial,
  };
}
